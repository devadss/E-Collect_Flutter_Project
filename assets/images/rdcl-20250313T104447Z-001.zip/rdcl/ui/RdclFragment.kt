package com.finwin.doorstep.agnl.home.transactions.rdcl.ui

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.finwin.doorstep.agnl.R
import com.finwin.doorstep.agnl.databinding.FragmentRdclBinding
import com.finwin.doorstep.agnl.home.transactions.loan_collection.search_loan_number.SearchLoanNumberActivity

class RdclFragment : Fragment() {
    private lateinit var rdclBinding: FragmentRdclBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        rdclBinding = DataBindingUtil.inflate(inflater ,R.layout.fragment_rdcl, container, false )
        onSearch()
        return rdclBinding.root
    }

    private fun onSearch(){
        rdclBinding.btnSearchLoan.setOnClickListener {
            startActivity(Intent(activity , SearchLoanNumberActivity::class.java))

        }
    }
}

